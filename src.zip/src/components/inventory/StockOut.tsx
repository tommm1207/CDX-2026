import { useState, useEffect, FormEvent } from 'react';
import { Plus, Search, ChevronRight, X, ArrowUpCircle, Edit, Navigation, Trash2, PackagePlus } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { supabase } from '../../supabaseClient';
import { Employee } from '../../types';
import { PageBreadcrumb } from '../shared/PageBreadcrumb';
import { NumericInput } from '../shared/NumericInput';
import { CreatableSelect } from '../shared/CreatableSelect';
import { ToastType } from '../shared/Toast';
import { ConfirmModal } from '../shared/ConfirmModal';
import { QuickAddMaterialModal } from '../shared/QuickAddMaterialModal';
import { useInventoryData } from '../../hooks/useInventoryData';
import { formatDate, formatCurrency, formatNumber } from '../../utils/format';
import { isUUID, generateCode } from '../../utils/helpers';
import { getAvailableStock } from '../../utils/inventory';

export const StockOut = ({ user, onBack, addToast }: { 
  user: Employee, 
  onBack?: () => void,
  addToast?: (message: string, type?: ToastType) => void 
}) => {
  const [slips, setSlips] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedSlip, setSelectedSlip] = useState<any>(null);
  const [submitting, setSubmitting] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [availableStock, setAvailableStock] = useState<number | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showAddMaterial, setShowAddMaterial] = useState(false);

  const { warehouses, materials, groups, refreshAll, fetchWarehouses } = useInventoryData();

  const initialFormState = {
    date: new Date().toISOString().split('T')[0],
    warehouse_id: '',
    material_id: '',
    quantity: 0,
    unit_price: 0,
    notes: '',
    status: 'Chờ duyệt',
    export_code: generateCode('XK')
  };

  const [stockLoading, setStockLoading] = useState(false);
  const [formData, setFormData] = useState(initialFormState);

  useEffect(() => {
    fetchSlips();
  }, []);

  useEffect(() => {
    if (formData.warehouse_id && formData.material_id && formData.date) {
      checkStock();
    } else {
      setAvailableStock(null);
    }
  }, [formData.warehouse_id, formData.material_id, formData.date, editingId]);

  const checkStock = async () => {
    const wh = warehouses.find(w => w.name === formData.warehouse_id || w.id === formData.warehouse_id);
    const mat = materials.find(m => m.name === formData.material_id || m.id === formData.material_id);

    if (!wh?.id || !mat?.id || !formData.date) return;

    setStockLoading(true);
    try {
      // Lấy tồn kho tích lũy đến đúng ngày của phiếu xuất.
      // Truyền editingId để loại trừ phiếu đang sửa khỏi tongXuat (tránh double-count).
      const stock = await getAvailableStock(mat.id, wh.id, formData.date, editingId || undefined);
      setAvailableStock(stock);
    } catch (err) {
      console.error('Error checking stock:', err);
    } finally {
      setStockLoading(false);
    }
  };

  const fetchSlips = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.from('stock_out').select('*, warehouses(name, code), materials(name, code, unit)').order('created_at', { ascending: false });
      if (error) {
        console.error('Error fetching stock_out:', error);
        const { data: fallbackData, error: fallbackError } = await supabase.from('stock_out').select('*').order('created_at', { ascending: false });
        if (fallbackError) throw fallbackError;
        setSlips(fallbackData || []);
      } else {
        setSlips(data || []);
      }
    } catch (err: any) {
      if (addToast) addToast('Lỗi tải phiếu xuất kho: ' + err.message, 'error');
      else alert('Lỗi tải phiếu xuất kho: ' + err.message);
    } finally {
      setLoading(false);
    }
  };


  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();

    // Explicit validation since custom components don't always trigger HTML5 forms properly
    if (!formData.warehouse_id) {
      if (addToast) addToast("Vui lòng chọn hoặc nhập Kho xuất.", "error");
      else alert("Vui lòng chọn hoặc nhập Kho xuất.");
      return;
    }
    if (!formData.material_id) {
      if (addToast) addToast("Vui lòng chọn hoặc nhập Vật tư xuất.", "error");
      else alert("Vui lòng chọn hoặc nhập Vật tư xuất.");
      return;
    }
    if (!formData.quantity || formData.quantity <= 0) {
      if (addToast) addToast("Vui lòng nhập số lượng xuất hợp lệ (lớn hơn 0).", "error");
      else alert("Vui lòng nhập số lượng xuất hợp lệ (lớn hơn 0).");
      return;
    }

    setSubmitting(true);
    try {
      let finalWarehouseId = formData.warehouse_id;
      if (formData.warehouse_id && !isUUID(formData.warehouse_id)) {
        const whByName = warehouses.find(w => w.name.toLowerCase() === formData.warehouse_id.toLowerCase());
        if (whByName) {
          finalWarehouseId = whByName.id;
        } else {
          const random = Math.floor(100 + Math.random() * 900);
          const code = `K${(warehouses.length + 1).toString().padStart(2, '0')}-${random}`;
          const { data: newWh, error: whErr } = await supabase.from('warehouses').insert([{ name: formData.warehouse_id, code }]).select();
          if (whErr) throw whErr;
          if (newWh) {
            finalWarehouseId = newWh[0].id;
            fetchWarehouses();
          }
        }
      }

      let finalMaterialId = formData.material_id;
      if (formData.material_id && !isUUID(formData.material_id)) {
        const matByName = materials.find(m => m.name.toLowerCase() === formData.material_id.toLowerCase());
        if (matByName) {
          finalMaterialId = matByName.id;
        } else {
          throw new Error('Bạn phải chọn vật tư từ Danh mục, không được tự nhập mới!');
        }
      }

      // Kiểm tra tồn kho tại ngày của phiếu xuất.
      // Loại trừ phiếu đang sửa (editingId) để không bị trừ double.
      const wh = warehouses.find(w => w.name === finalWarehouseId || w.id === finalWarehouseId);
      const stockAtDate = await getAvailableStock(
        finalMaterialId,
        wh?.id || finalWarehouseId,
        formData.date,
        isEditing && selectedSlip ? selectedSlip.id : undefined
      );
      if (Number(formData.quantity) > stockAtDate) {
        throw new Error(`Không đủ tồn kho tại ngày ${formData.date}! Tồn hiện có: ${stockAtDate}, cần xuất: ${formData.quantity}.`);
      }

      const payload = {
        ...formData,
        warehouse_id: finalWarehouseId,
        material_id: finalMaterialId,
        employee_id: user.id,
        status: 'Chờ duyệt',
        total_amount: formData.quantity * formData.unit_price,
        export_code: formData.export_code || generateCode('XK'),
        notes: isEditing ? `[SỬA] ${formData.notes}` : formData.notes
      };

      if (isEditing && selectedSlip) {
        const { error } = await supabase.from('stock_out').update(payload).eq('id', selectedSlip.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('stock_out').insert([payload]);
        if (error) throw error;

      }

      setShowModal(false);
      fetchSlips();
      setFormData(initialFormState);
      setIsEditing(false);
      setEditingId(null);
      setSelectedSlip(null);
      if (addToast) addToast(isEditing ? 'Đã cập nhật phiếu xuất!' : 'Đã lưu phiếu xuất kho!', 'success');
    } catch (err: any) {
      if (addToast) addToast('Lỗi: ' + err.message, 'error');
      else alert('Lỗi: ' + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleApprove = async (id: string, status: string) => {
    try {
      const { error } = await supabase.from('stock_out').update({ status }).eq('id', id);
      if (error) throw error;
      
      if (status === 'Đã duyệt') {
        const { data: slip } = await supabase.from('stock_out').select('*, users(id)').eq('id', id).maybeSingle();
        if (slip && (slip as any).total_amount > 0) {
          // Check if cost already exists to prevent duplicates
          const { data: existingCost } = await supabase
            .from('costs')
            .select('id')
            .ilike('content', `%${slip.export_code || slip.id.slice(0,8)}%`)
            .maybeSingle();

          if (!existingCost) {
            const dateObj = new Date(slip.date);
            const d = String(dateObj.getDate()).padStart(2, '0');
            const m = String(dateObj.getMonth() + 1).padStart(2, '0');
            const y = String(dateObj.getFullYear()).slice(-2);
            const random = Math.floor(1000 + Math.random() * 9000);
            const userPrefix = (slip as any).users?.id?.slice(0, 4) || 'SYS';
            const costCode = `CP-${userPrefix.toUpperCase()}-${d}${m}${y}-${random}`;

            await supabase.from('costs').insert([{
              transaction_type: 'Thu',
              cost_code: costCode,
              date: slip.date,
              employee_id: user.id,
              cost_type: 'Doanh thu',
              content: `Xuất kho từ phiếu ${slip.export_code || slip.id.slice(0,8)}`,
              material_id: slip.material_id,
              warehouse_id: slip.warehouse_id,
              quantity: slip.quantity,
              unit: (slip as any).unit,
              unit_price: (slip as any).unit_price,
              total_amount: (slip as any).total_amount,
              notes: 'Tự động tạo từ hệ thống Xuất Kho'
            }]);
          }
        }
      }

      fetchSlips();
      setShowDetailModal(false);
      if (addToast) addToast('Cập nhật trạng thái thành công!', 'success');
    } catch (err: any) {
      if (addToast) addToast('Lỗi: ' + err.message, 'error');
      else alert('Lỗi: ' + err.message);
    }
  };

  const handleDelete = () => {
    if (!selectedSlip) return;
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    try {
      const { error } = await supabase.from('stock_out').update({ status: 'Đã xóa' }).eq('id', selectedSlip.id);
      if (error) throw error;

      // Also void associated cost
      await supabase.from('costs')
        .update({ status: 'Đã xóa' })
        .ilike('content', `%${selectedSlip.export_code || selectedSlip.id.slice(0,8)}%`);
      
      if (addToast) addToast('Đã chuyển phiếu vào thùng rác', 'success');
      setShowDetailModal(false);
      setShowDeleteConfirm(false);
      fetchSlips();
    } catch (err: any) {
      const msg = err.message.includes('foreign key constraint') 
        ? 'Không thể xóa phiếu này vì đang có dữ liệu liên quan khác.' 
        : err.message;
      if (addToast) addToast('Lỗi: ' + msg, 'error');
      else alert('Lỗi: ' + msg);
    }
  };

  const handleRowClick = (slip: any) => {
    setSelectedSlip(slip);
    setShowDetailModal(true);
  };

  const handleEdit = () => {
    setFormData({
      date: selectedSlip.date,
      warehouse_id: selectedSlip.warehouse_id,
      material_id: selectedSlip.material_id,
      quantity: selectedSlip.quantity,
      unit_price: selectedSlip.unit_price || 0,
      notes: selectedSlip.notes?.replace('[SỬA] ', '') || '',
      status: 'Chờ duyệt'
    });
    setIsEditing(true);
    setEditingId(selectedSlip.id);  // lưu id để loại trừ khỏi tính tồn
    setShowDetailModal(false);
    setShowModal(true);
  };

  return (
    <div className="p-4 md:p-6 space-y-6 pb-44">
      <PageBreadcrumb title="Xuất kho" onBack={onBack} />
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
            <ArrowUpCircle className="text-red-500" /> Xuất kho
          </h2>
          <p className="text-xs text-gray-500 mt-1">Quản lý phiếu xuất vật tư khỏi kho</p>
        </div>
        <button
          onClick={() => {
            setFormData({
              ...initialFormState,
              export_code: generateCode('XK')
            });
            setIsEditing(false);
            setEditingId(null);
            setShowModal(true);
          }}
          className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-xl text-sm font-bold hover:bg-red-700 transition-colors shadow-lg shadow-red-600/20"
        >
          <Plus size={18} /> Lập phiếu xuất
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[700px]">
            <thead>
              <tr className="bg-red-600 text-white">
                <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-wider">Ngày</th>
                <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-wider">Kho</th>
                <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-wider">Vật tư</th>
                <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-wider text-center">SL</th>
                <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-wider">Trạng thái</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading ? (
                <tr><td colSpan={5} className="px-4 py-8 text-center text-gray-400 italic">Đang tải...</td></tr>
              ) : slips.length === 0 ? (
                <tr><td colSpan={5} className="px-4 py-8 text-center text-gray-400 italic">Chưa có phiếu xuất nào</td></tr>
              ) : (
                slips.map((item) => (
                  <tr key={item.id} onClick={() => handleRowClick(item)} className="hover:bg-gray-50 transition-colors cursor-pointer group">
                    <td className="px-4 py-3 text-xs text-gray-600">{formatDate(item.date)}</td>
                    <td className="px-4 py-3 text-xs text-gray-600 font-medium">
                      <p>{item.warehouses?.name}</p>
                      <p className="text-[10px] text-gray-400">#{item.warehouses?.code}</p>
                    </td>
                    <td className="px-4 py-3 text-xs text-gray-600">
                      <p>{item.materials?.name}</p>
                      <p className="text-[10px] text-gray-400">#{item.materials?.code}</p>
                    </td>
                    <td className="px-4 py-3 text-xs text-red-600 text-center font-bold">-{item.quantity}</td>
                    <td className="px-4 py-3 text-xs">
                      <div className="flex items-center justify-between">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${item.status === 'Đã duyệt' ? 'bg-green-100 text-green-600' :
                            item.status === 'Từ chối' ? 'bg-red-100 text-red-600' : 'bg-amber-100 text-amber-600'
                          }`}>
                          {item.status || 'Chờ duyệt'}
                        </span>
                        <ChevronRight size={14} className="text-gray-300 group-hover:text-primary transition-colors" />
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <AnimatePresence>
        {showDetailModal && selectedSlip && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden"
            >
              <div className="bg-red-600 p-6 text-white flex items-center justify-between">
                <h3 className="font-bold text-lg">Chi tiết phiếu xuất</h3>
                <button onClick={() => setShowDetailModal(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors"><X size={20} /></button>
              </div>
              <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                  <div>
                    <p className="text-[10px] font-bold text-gray-400 uppercase">Ngày xuất</p>
                    <p className="text-sm font-bold text-gray-800">{formatDate(selectedSlip.date)}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-gray-400 uppercase">Trạng thái</p>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${selectedSlip.status === 'Đã duyệt' ? 'bg-green-100 text-green-600' :
                        selectedSlip.status === 'Từ chối' ? 'bg-red-100 text-red-600' : 'bg-amber-100 text-amber-600'
                      }`}>
                      {selectedSlip.status || 'Chờ duyệt'}
                    </span>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-gray-400 uppercase">Kho xuất</p>
                    <p className="text-sm font-bold text-gray-800">{selectedSlip.warehouses?.name}</p>
                    <p className="text-[10px] text-gray-400">Mã: {selectedSlip.warehouses?.code || selectedSlip.warehouse_id?.slice(0, 8)}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-gray-400 uppercase">Vật tư</p>
                    <p className="text-sm font-bold text-gray-800">{selectedSlip.materials?.name}</p>
                    <p className="text-[10px] text-gray-400">Mã: {selectedSlip.materials?.code || selectedSlip.material_id?.slice(0, 8)}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-red-400 uppercase">Số lượng</p>
                    <p className="text-sm font-bold text-red-600">-{formatNumber(selectedSlip.quantity)}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-gray-400 uppercase">Đơn giá bán</p>
                    <p className="text-sm font-medium text-gray-800">{formatCurrency(selectedSlip.unit_price || 0)}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-gray-400 uppercase">Thành tiền (Doanh thu)</p>
                    <p className="text-sm font-bold text-green-600">{formatCurrency(selectedSlip.total_amount || 0)}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-gray-400 uppercase">Ghi chú</p>
                    <p className="text-sm text-gray-600 italic">{selectedSlip.notes || 'Không có ghi chú'}</p>
                  </div>

                <div className="flex gap-3 pt-4 border-t border-gray-100">
                  {selectedSlip.status !== 'Đã xóa' && (
                    <>
                      <button
                        onClick={handleDelete}
                        className="flex-1 flex items-center justify-center gap-2 py-2 bg-red-50 text-red-600 rounded-xl text-sm font-bold hover:bg-red-100 transition-colors"
                      >
                        <Trash2 size={18} /> Chuyển vào thùng rác
                      </button>
                      <button
                        onClick={handleEdit}
                        className="flex-1 flex items-center justify-center gap-2 py-2 bg-blue-50 text-blue-600 rounded-xl text-sm font-bold hover:bg-blue-100 transition-colors"
                      >
                        <Edit size={18} /> Chỉnh sửa
                      </button>
                      {((user.role === 'Admin' || user.role === 'Admin App') && selectedSlip.status === 'Chờ duyệt') && (
                        <>
                          <button
                            onClick={() => handleApprove(selectedSlip.id, 'Từ chối')}
                            className="flex-1 py-2 bg-red-100 text-red-600 rounded-xl text-sm font-bold hover:bg-red-200 transition-colors"
                          >
                            Từ chối
                          </button>
                          <button
                            onClick={() => handleApprove(selectedSlip.id, 'Đã duyệt')}
                            className="flex-1 py-2 bg-green-600 text-white rounded-xl text-sm font-bold hover:bg-green-700 transition-colors"
                          >
                            Duyệt phiếu
                          </button>
                        </>
                      )}
                    </>
                  )}
                  <button
                    onClick={() => setShowDetailModal(false)}
                    className="flex-1 py-2 bg-gray-100 text-gray-500 rounded-xl text-sm font-bold hover:bg-gray-200 transition-colors"
                  >
                    Đóng
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col"
            >
              <div className="bg-red-600 p-6 text-white flex items-center justify-between rounded-t-3xl flex-shrink-0">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-white/20 rounded-xl"><ArrowUpCircle size={24} /></div>
                  <h3 className="font-bold text-lg">{isEditing ? 'Sửa phiếu xuất kho' : 'Lập phiếu xuất kho'}</h3>
                </div>
                <button onClick={() => setShowModal(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors"><X size={20} /></button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
                <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-32">
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Ngày xuất *</label>
                      <input 
                        type="date" 
                        required 
                        value={formData.date} 
                        onChange={(e) => setFormData({ ...formData, date: e.target.value })} 
                        className="w-full px-4 py-2 rounded-xl border border-gray-200 text-sm outline-none focus:ring-2 focus:ring-red-600/20" 
                      />
                      <p className="text-[10px] text-gray-400">Tồn kho sẽ được kiểm tra tại ngày này</p>
                    </div>

                    <CreatableSelect
                      label="Kho xuất *"
                      value={formData.warehouse_id}
                      options={warehouses}
                      onChange={(val) => setFormData({ ...formData, warehouse_id: val })}
                      onCreate={(val) => setFormData({ ...formData, warehouse_id: val })}
                      placeholder="Chọn kho..."
                      required
                    />

                    <div className="flex items-end gap-2 relative z-[120]">
                      <div className="flex-1">
                        <CreatableSelect
                          label="Vật tư *"
                          value={formData.material_id}
                          options={materials}
                          onChange={(val) => setFormData({ ...formData, material_id: val })}
                          onCreate={() => addToast?.('Vui lòng chọn vật tư có trong Danh mục. Hoặc click nút + bên cạnh để tạo mới.', 'error')}
                          placeholder="Chọn vật tư..."
                          required
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => setShowAddMaterial(true)}
                        className="h-[42px] px-3 bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-100 transition-colors flex items-center justify-center shrink-0 border border-blue-100"
                        title="Thêm vật tư nhanh"
                      >
                        <PackagePlus size={20} />
                      </button>
                    </div>

                    {stockLoading && (
                      <div className="p-3 bg-gray-50 rounded-xl border border-gray-100">
                        <p className="text-[10px] font-bold text-gray-400 uppercase animate-pulse">Đang kiểm tra tồn kho...</p>
                      </div>
                    )}
                    {!stockLoading && availableStock !== null && (
                      <div className={`p-3 rounded-xl border ${
                        availableStock <= 0
                          ? 'bg-red-50 border-red-100'
                          : availableStock <= 5
                          ? 'bg-amber-50 border-amber-100'
                          : 'bg-blue-50 border-blue-100'
                      }`}>
                        <p className={`text-[10px] font-bold uppercase ${
                          availableStock <= 0 ? 'text-red-400' : availableStock <= 5 ? 'text-amber-400' : 'text-blue-400'
                        }`}>Tồn kho tại ngày {formData.date}</p>
                        <p className={`text-sm font-bold ${
                          availableStock <= 0 ? 'text-red-600' : availableStock <= 5 ? 'text-amber-600' : 'text-blue-600'
                        }`}>
                          {formatNumber(availableStock)} {materials.find(m => m.id === formData.material_id || m.name === formData.material_id)?.unit}
                          {availableStock <= 0 && ' ⚠ Không đủ tồn kho!'}
                        </p>
                      </div>
                    )}
                  </div>

                  <div className="space-y-4">
                    <NumericInput
                      label="Số lượng xuất *"
                      required
                      value={formData.quantity}
                      onChange={(val) => setFormData({ ...formData, quantity: val })}
                    />

                    <NumericInput
                      label="Đơn giá bán"
                      value={formData.unit_price}
                      onChange={(val) => setFormData({ ...formData, unit_price: val })}
                      step={1000}
                    />

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Ghi chú / Mục đích xuất</label>
                      <textarea rows={4} value={formData.notes} onChange={(e) => setFormData({ ...formData, notes: e.target.value })} className="w-full px-4 py-2 rounded-xl border border-gray-200 text-sm outline-none focus:ring-2 focus:ring-red-600/20 resize-none" />
                    </div>
                  </div>

                  <div className="md:col-span-2 flex justify-end gap-3 mt-4">
                    <button type="button" onClick={() => setShowModal(false)} className="px-6 py-2 rounded-xl text-sm font-bold text-gray-500 hover:bg-gray-100 transition-colors">Hủy</button>
                    <button
                      type="submit"
                      disabled={submitting || (availableStock !== null && Number(formData.quantity) > availableStock)}
                      title={availableStock !== null && Number(formData.quantity) > availableStock ? `Không đủ tồn kho (tồn: ${availableStock})` : undefined}
                      className="px-8 py-2 rounded-xl bg-red-600 text-white text-sm font-bold hover:bg-red-700 transition-colors shadow-lg shadow-red-600/20 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {submitting ? 'Đang lưu...' : (isEditing ? 'Cập nhật' : 'Lưu phiếu xuất')}
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <QuickAddMaterialModal
        show={showAddMaterial}
        onClose={() => setShowAddMaterial(false)}
        groups={groups}
        addToast={addToast}
        onSuccess={(newMat) => {
          setFormData({ ...formData, material_id: newMat.id });
          refreshAll();
        }}
      />

      <ConfirmModal
        show={showDeleteConfirm}
        title="Xác nhận xóa"
        message="Bạn có chắc chắn muốn chuyển phiếu xuất kho này vào thùng rác? Hành động này cũng sẽ vô hiệu hóa bản ghi doanh thu liên quan."
        confirmText="Chuyển vào thùng rác"
        onConfirm={confirmDelete}
        onCancel={() => setShowDeleteConfirm(false)}
      />
    </div>
  );
};
